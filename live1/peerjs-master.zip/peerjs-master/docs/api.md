# PeerJS API Reference

We've moved! <a href="https://peerjs.com/docs.html#api">Check out our new API
reference.</a>

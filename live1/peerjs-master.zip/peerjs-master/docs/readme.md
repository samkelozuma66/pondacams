## PeerJS Documentation

We've moved! <a href="https://peerjs.com/docs.html">Check out our new
documentation.</a>

### [Discuss PeerJS on our Telegram Channel](https://t.me/joinchat/ENhPuhTvhm8WlIxTjQf7Og)

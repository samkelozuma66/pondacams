import webRTCAdapter from "webrtc-adapter";

export { webRTCAdapter };
